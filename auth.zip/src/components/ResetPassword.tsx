import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL || '',
  import.meta.env.VITE_SUPABASE_ANON_KEY || ''
);

const ResetPassword: React.FC = () => {
  const [newPassword, setNewPassword] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const url = window.location.href;
    console.log("URL:", url);

    const hashFragment = url.split('#')[2];
    console.log("Hash Fragment:", hashFragment);

    if (hashFragment) {
      const params = new URLSearchParams(hashFragment);
      const extractedToken = params.get('access_token');
      console.log("Extracted Token:", extractedToken);
      setToken(extractedToken);
    }
  }, []);

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      setError('Invalid or missing token.');
      return;
    }
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      if (error) throw error;
      setMessage('Password has been reset successfully.');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <form onSubmit={handleResetPassword}>
      <input
        type="password"
        value={newPassword}
        onChange={(e) => setNewPassword(e.target.value)}
        placeholder="New Password"
        required
      />
      <button type="submit">Reset Password</button>
      {message && <p>{message}</p>}
      {error && <p>{error}</p>}
    </form>
  );
};

export default ResetPassword; 