import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL || '',
  import.meta.env.VITE_SUPABASE_ANON_KEY || ''
);

const ForgotPassword: React.FC = () => {
  const [email, setEmail] = useState('jrixcgeromo@gmail.com');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Forgot Password form submitted");
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: 'http://localhost:5173/#/reset-password'
      });
      if (error) throw error;
      setMessage('Password reset email sent successfully.');
    } catch (err: any) {
      setError(err.message);
    }
  };

  useEffect(() => {
    const hash = window.location.hash;
    console.log("Hash:", hash);
    const params = new URLSearchParams(hash.substring(1));
    const extractedToken = params.get('access_token');
    console.log("Extracted Token:", extractedToken);
    setToken(extractedToken);
  }, []);

  return (
    <form onSubmit={handleForgotPassword}>
      <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
      <button type="submit">Reset Password</button>
      {message && <p>{message}</p>}
      {error && <p>{error}</p>}
    </form>
  );
};

export default ForgotPassword; 